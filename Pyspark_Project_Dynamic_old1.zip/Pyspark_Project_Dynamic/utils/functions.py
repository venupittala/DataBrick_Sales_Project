# Databricks notebook source
def func_read_csv(path,schema):
        """schema
        This function creates a pyspark dataframe by reading the
        parameters  input file path and input filename.
  
        input:
           : param input_file_path: File path till the root directory or file name with location.
           : schema : predefied schema variable
           : badpath : rejected records storage location (use for badrecordspath option)
                       option("badRecordsPath", "/tmp/badRecordsPath")  
        output:
            pyspark dataframe : Return the Pyspark Dataframe   
        """
        try:
            df_csv = spark.read.schema(schema)\
          .option("mode", "PERMISSIVE")\
          .option("nullValue","null")\
          .csv(path,header=True,sep=",",ignoreLeadingWhiteSpace=True,\
           ignoreTrailingWhiteSpace=True,\
           columnNameOfCorruptRecord="_corrupt_record").withColumn("input_file_name",input_file_name())
            if df_csv is None:
                raise FileNotFoundError("Unable to read dataframe. Please configure input_file_path!")
        except:
            func_register_log("ERROR", "Error counting total nulls  per column of file {type}:"+str(sys.exc_info()[1]))
            return False
        return df_csv

# COMMAND ----------

def func_read_json(input_file_path):
        """
        This function creates a pyspark dataframe by reading the
        parameters  input file path and input filename.
  
        input:
           :param input_file_path: File path till the root directory or file name with location.
  
        output:
            pyspark dataframe : Return the Pyspark Dataframe  
        """
        try:
            df_json = spark.read.option("mode", "PERMISSIVE")\
                                .option("columnNameOfCorruptRecord", "_corrupt_record")\
                                .json(input_file_path)
          
            if df_json is None:
                raise FileNotFoundError("Unable to read dataframe. Please configure input_file_path!")
        except Exception as e:
            print(e)
            return False
        return df_json

# COMMAND ----------

def func_data_quality_duplicate_check(df):
        """
        Aim: Takes main DataFrame and take seperate count unique and total counts.
        Input params: 
            total : Total Rows 
            unique : unique Rows
        return: None
        """
        logging.info('Performing Duplicate Data quality checks...')
        total=df.count()
        unique=df.dropDuplicates().count()
        if (total-unique)==0:
            logging.info("There is no Duplicates, quality check passsed")
            return True
        else:
            logging.info("Duplicates Found : {}  Duplicate Rows    ".format(total-unique) ) 
            return False
    
    # This Function will validate any NULL data columns in all fields...
    
    

# COMMAND ----------

def func_data_quality_null_check(df):
        """Function returns results of null checks for each column and total rows in table
        Input:
            - title   : STRING, title of table
            - sparkdf : a spark dataframe
        """
        sparkdf_columns = df.columns
        total = df.count()
        logging.info(" ")
        logging.info('Performing quality checks for {}'.format(self.source))
        for colname in sparkdf_columns:
            null_values= df.filter(df[colname].isNull()).count()
            logging.info('Number of null values for {} is: {}'.format(colname, null_values))        
        logging.info('Total number of rows is: {}'.format(total))
        logging.info(" ")
        return True

# COMMAND ----------

from py4j.protocol import Py4JJavaError

def func_create_widgets(widgets):
  """ This function we are using for creating multiple wisgets.
      While moving code from one environment to other it wont be moved.
      So it should be created each environment.
      
      Import all the widgets listed in widgets, and create any missing ones
      Default to dbutils.widgets.text, with blank defaultvalue
  """
  
  for v in widgets:
    try:
      globals()[v] = dbutils.widgets.get(v)
    except Py4JJavaError:
      dbutils.widgets.text(v,"")
      globals()[v] = dbutils.widgets.get(v)
      
    except:
      func_register_log("ERROR", "Error counting total nulls  per column of file {type}:"+str(sys.exc_info()[1]))

# COMMAND ----------

 def func_remove_null_duplicate(df,pk):
  """Function returns results of null checks for each column and total rows in table
        Input:
            - title   : STRING, title of table
            - sparkdf : a spark dataframe
  """
  try:
    df = df.dropDuplicates(pk.split(","))
    df = df.fillna(0).fillna('')
  except:
    func_register_log("ERROR", "Error counting total nulls  per column of file {type}:"+str(sys.exc_info()[1]))     
        
  return df

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
# ETL log record table schema
log_table_schema = StructType ([
  StructField ('created_date', TimestampType (), True),
  StructField ('log_type', StringType (), True),
  StructField ('log_description', StringType (), True)
  ])

# DataFrame with the ETL log record
df_log = spark.createDataFrame ([], log_table_schema)

# COMMAND ----------

# Function to record the process log
def func_register_log(log_type, log_description):
  """
  This function we can use for cutom logging using dataframe and table
  input Parameters:
  log_type: you can pass log type like ERROR , INFO, DATA-VALIDATION..
  log_description : log description like error message or row count .. duplicate data count...
  """
  from datetime import datetime
  values_to_register = [(datetime.now(),log_type,log_description)]
  newRow = spark.createDataFrame (values_to_register).toDF("created_date","log_type","log_description")
  
  global df_log
  df_log = df_log.union(newRow).distinct()
  #df_log.show()
  if log_type == "ERROR":    
    # Store the worked log in the dataframe in the final table
    df_log.write.format("delta").option("mergeSchema","true").mode("append").saveAsTable("log_db.job_audit_log")
    # Exit notebook execution
    #dbutils.notebook.exit (log_description)
    

# COMMAND ----------

# Function to support the EDA process, validating the total of null-voids per column
def func_validate_nulldata (type, df):
  """
  This function we can use for to validate null data in dataframe
  """
  try:
    #We count total of nulls and voids that exist per column
    # isnan(c) will work for non date datatypes. if you have any date datatype dont use isnan(c)
    # df.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df.columns]).show()
    dfEmptyColumns = df.select([count(when(col(c).isNull(), c)).alias(c) for c in df.columns])
    #We select only the columns that have null or empty
    dfEmptyColumns = dfEmptyColumns.select([key for (key,value) in dfEmptyColumns.collect()[0].asDict().items() if value> 0])
    #Register in the log
    for column,total in dfEmptyColumns.collect()[0].asDict().items():
      func_register_log("DATA-VALIDATION", f"Empty-Null file {type}, column: {column}, total: {total}")
  except:
    func_register_log("ERROR", "Error counting total nulls  per column of file {type}:"+str(sys.exc_info()[1]))

# COMMAND ----------

# Function to find duplicate records
def func_validate_duplicatedata(type, df):
  """
  This function for to validate dupliate rows in any dataframe.
  """  
  try:
    total = df.groupBy([c for c in df.columns]).count().filter("count > 1").count()
  except:
    func_register_log("ERROR", "Error counting total duplicate records in file {type}:"+str(sys.exc_info()[1]))
  else:
    func_register_log("DATA-VALIDATION",f'File duplicates {type}, total: {total}')

# COMMAND ----------

def func_get_count_by_partition(df):
  from pyspark.sql.functions import spark_partition_id
  '''
  Using spark_partition_id() function we can get partition id and get count on each partition using groupby
  '''
  print("Per-Partition Counts:")
  # Creating new column as partition_id using spark_partition_id() function
  df = df.withColumn("partition_id",spark_partition_id())
  # Taking count on each partition using groupBy("partition_id") and orderBy("partition_id")
  results = df.groupBy("partition_id").count().orderBy("partition_id")
  # Looping each partition count using for loop
  for a,b in results.collect(): 
    print("Partition id : {} And No Of Rows : {} ".format(a,b))

# COMMAND ----------

def func_gen_monotonically_id(df,pk):
  from pyspark.sql.functions import monotonically_increasing_id
  '''
  Using spark_partition_id() function we can get partition id and get count on each partition using groupby
  '''
  print("Per-Partition Counts:")
  # Creating new column as partition_id using monotonically_increasing_id() function
  df = df.withColumn(pk,monotonically_increasing_id())
  
  return df

# COMMAND ----------

def func_add_audit_cols(df):
  from pyspark.sql.functions import md5,col,concat,lit,current_timestamp
  '''
  Adding Audit columns in all dataframes before writing into table
  '''
  try:
    df = df.withColumn('CREATED_DATE',lit(current_timestamp()))\
              .withColumn('CREATED_BY',lit('ETLJOB'))\
              .withColumn('UPDATED_DATE',lit(current_timestamp()))\
              .withColumn('UPDATED_BY',lit('ETLJOB'))
  except Exception as e:
    func_register_log ("ERROR", "Error While adding audit columns:" + str(sys.exc_info()[1]))
    raise dbutils.notebook.exit(e) #raise the exception
  
  return df

# COMMAND ----------

def func_delete_tables(db) :
  """
  Drop all tables from database specific
  """
  try:
    tables=spark.catalog.listTables(db)
  except:
    return
  for table in tables:
      spark.sql("DROP TABLE {}.{}".format(db, table.name))
      print("DROPPED TABLE {}.{}".format(db, table.name))
      
# deleteTables()

# COMMAND ----------

def flatten_structs(nested_df):
  """
  this function we can use for identifying nested data types like  ARRAY and STRUCT type fields and 
  Creating individual datatypes with underscore _ 
  input Param:  Pyspark Dataframe
  
  """
    # Creating python list to store dataframe metadata
  stack = [((), nested_df)]
    # Creating empty python list for storing identified nested data type columns information
  columns = []

  while len(stack) > 0:
      # Removing latest or recently added item (dataframe schema) and returning into df variable  
      parents, df = stack.pop()
      # Reading data types one by one using loop and validating array type and getting those  
      array_cols = [  c[0]  for c in df.dtypes   if c[1][:5] == "array"  ]
      
      # 
      flat_cols = [  f.col(".".join(parents + (c[0],))).alias("_".join(parents + (c[0],)))
            for c in df.dtypes
            if c[1][:6] != "struct"   ]
      
      nested_cols = [  c[0]   for c in df.dtypes if c[1][:6] == "struct"   ]
      # appending all columns
      
      columns.extend(flat_cols)
      #Reading  nested columns and appending into stack list
      
      for nested_col in nested_cols:
            projected_df = df.select(nested_col + ".*")
            stack.append((parents + (nested_col,), projected_df))
            
      
      
  return nested_df.select(columns)

# COMMAND ----------

def flatten_array_struct_df(df):
  """
  Using this function reading all nested columns and converting into normal columns.
  """
    # getting no of array columns for looping
  array_cols = [  c[0]   for c in df.dtypes  if c[1][:5] == "array"   ]
    
  while len(array_cols) > 0:
        
      for array_col in array_cols:            
        cols_to_select = [x for x in df.columns if x != array_col ] 
        # Using Explode function flattening the data
        df = df.withColumn(array_col, f.explode(f.col(array_col)))
      # calling above function to update latest fields. 
      
      df = flatten_structs(df)
      
      # reducing number based latest updated columns
      array_cols = [   c[0]  for c in df.dtypes    if c[1][:5] == "array"     ]
        
  return df



# COMMAND ----------

def func_final_log_append():
  """
  this function we can trigger end of notebook to log information or audit logging int job_audit_log table
  """
  
  try:
    df_log.write.format("delta").option("mergeSchema","true").mode("append").saveAsTable("log_db.job_audit_log")
  except:
    func_register_log("ERROR", "Error while appending information :"+str(sys.exc_info()[1]))

# COMMAND ----------

def func_synapse_update_dwh(df,dwhStagingTable,dwhTargetTable,lookupColumns,updatedDate,dwhStagingDistributionColumn,sqldwJDBC,tempSQLDWFolder):
  """
  df: main dataframe data to be written in synapse
  dwhTargetTable: staging for loads data from df to synapse staging
  dwhTargetTable: target table as main final table data will get data from staging table.
  lookupColumns: common join column conditional columns in seperated by comma , 
  updatedDate : timestamp column for verifying incremental data.
  dwhStagingDistributionColumn : PK key column for creating index
  sqldwJDBC = "Your JDBC Connection String for Azure Synapse Analytics. Preferably from Key Vault"
  tempSQLDWFolder = "A temp folder in Azure Datalake Storage or Blob Storage for temp polybase files "  
  """
  
  try:
     
    #STEP1: Derive dynamic delete statement to delete existing record from TARGET if the source record is newer
    lookupCols =lookupColumns.split(",")
    whereClause=""
    for col in lookupCols:
      whereClause= whereClause + dwhStagingTable  +"."+ col  + "="+ dwhTargetTable +"." + col + " and "
 
    if updatedDate is not None and  len(updatedDate) >0:
      #Check if the last updated is greater than existing record
      whereClause= whereClause + dwhStagingTable  +"."+ updatedDate  + ">="+ dwhTargetTable +"." + updatedDate
    else:
      #remove last "and"
      remove="and"
      reverse_remove=remove[::-1]
      whereClause = whereClause[::-1].replace(reverse_remove,"",1)[::-1]
 
    deleteSQL = "delete from " + dwhTargetTable + " where exists (select 1 from " + dwhStagingTable + " where " +whereClause +");"
 
    #STEP2: Delete existing records but outdated records from SOURCE
    whereClause=""
    for col in lookupCols:
      whereClause= whereClause + dwhTargetTable  +"."+ col  + "="+ dwhStagingTable +"." + col + " and "
 
    if updatedDate is not None and  len(updatedDate) >0:
      #Check if the last updated is lesser than existing record
      whereClause= whereClause + dwhTargetTable  +"."+ deltaName  + "> "+ dwhStagingTable +"." + updatedDate
    else:
      #remove last "and"
      remove="and"
      reverse_remove=remove[::-1]
      whereClause = whereClause[::-1].replace(reverse_remove,"",1)[::-1]
 
    deleteOutdatedSQL = "delete from " + dwhStagingTable + " where exists (select 1 from " + dwhTargetTable + " where " + whereClause + " );"
    #print("deleteOutdatedSQL={}".format(deleteOutdatedSQL))
 
    #STEP3: Insert SQL
    insertSQL ="Insert Into " + dwhTargetTable + " select * from " + dwhStagingTable +";"
    #print("insertSQL={}".format(insertSQL))
 
    #consolidate post actions SQL
    postActionsSQL = deleteSQL + deleteOutdatedSQL + insertSQL
    print("postActionsSQL={}".format(postActionsSQL))
 
    
     
     
    #Use Hash Distribution on STG table where possible
    if dwhStagingDistributionColumn is not None and len(dwhStagingDistributionColumn) > 0:
      stgTableOptions ="CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH (" +  dwhStagingDistributionColumn + ")"
    else:
      stgTableOptions ="CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN"
     
    #Upsert/Merge to Target using STG postActions
    df.write.format("com.databricks.spark.sqldw")\
      .option("url", sqldwJDBC).option("forwardSparkAzureStorageCredentials", "true")\
      .option("dbTable",dwhStagingTable)\
      .option("tableOptions",stgTableOptions)\
      .option("tempDir",tempSQLDWFolder)\
      .option("maxStrLength",4000)\
      .option("postActions",postActionsSQL)\
      .mode("overwrite").save()
    
  except Exception as e:
    print(e)
    func_register_log("ERROR", "Error counting total nulls  per column of file {type}:"+str(sys.exc_info()[1]))
    
    