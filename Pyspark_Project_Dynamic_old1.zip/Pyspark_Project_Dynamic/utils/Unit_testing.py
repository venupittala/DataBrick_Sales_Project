# Databricks notebook source
# MAGIC %md
# MAGIC ### Python UnitTest
# MAGIC * The unittest unit testing framework was originally inspired by JUnit and has a similar flavor as major unit testing frameworks in other languages. It supports test automation, sharing of setup and shutdown code for tests, aggregation of tests into collections, and independence of the tests from the reporting framework.
# MAGIC 
# MAGIC ##### test fixture
# MAGIC * A test fixture represents the preparation needed to perform one or more tests, and any associated cleanup actions. This may involve, for example, creating temporary or proxy databases, directories, or starting a server process.
# MAGIC 
# MAGIC ##### test case
# MAGIC * A test case is the individual unit of testing. It checks for a specific response to a particular set of inputs. unittest provides a base class, TestCase, which may be used to create new test cases.
# MAGIC 
# MAGIC ##### test suite
# MAGIC * A test suite is a collection of test cases, test suites, or both. It is used to aggregate tests that should be executed together.
# MAGIC 
# MAGIC ##### test runner
# MAGIC * A test runner is a component which orchestrates the execution of tests and provides the outcome to the user. The runner may use a graphical interface, a textual interface, or return a special value to indicate the results of executing the tests.

# COMMAND ----------

#Creating Add function for addition
def add(a, b):
    return a + b
#Creating multi function for multiplication
def multi(a,b):
  return a*b

# COMMAND ----------

add(5,5)

# COMMAND ----------

import unittest 

#Creating Class for Unit Testing
class test_class(unittest.TestCase):
    def test_add(self):
      self.assertEqual(20, add(15, 5))
    def test_multi(self):
      self.assertEqual(10,multi(5,2))
    
# create a test suite  for test_class using  loadTestsFromTestCase()
suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
#Running test cases using Test Cases Suit..
unittest.TextTestRunner(verbosity=2).run(suite)