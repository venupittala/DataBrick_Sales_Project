# Databricks notebook source
# MAGIC %md
# MAGIC ###Overview
# MAGIC 
# MAGIC This is a caller notebook used to perform Custom Loggin in all the python notebooks.
# MAGIC 
# MAGIC ###Details
# MAGIC | Detail Tag | Information
# MAGIC | - | - | - | - |
# MAGIC | Originally Created By | Raveendra  
# MAGIC | Object Name | Landing To Staging
# MAGIC | File Type |  .csv file To Delta Table
# MAGIC | Target Location | Databricks Mount Path External Table 
# MAGIC 
# MAGIC ###History
# MAGIC |Date | Developed By | comments
# MAGIC |----|-----|----
# MAGIC |05/12/2020|Ravendra| Initial Version
# MAGIC | Find more Videos | Youtube   | <a href="https://www.youtube.com/watch?v=FpxkiGPFyfM&list=PL50mYnndduIHRXI2G0yibvhd3Ck5lRuMn" target="_blank"> Youtube link </a>|

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import common libraries from libraries notebook

# COMMAND ----------

# MAGIC %run "/Shared/Pyspark_Project_Dynamic/utils/libraries"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Calling Common utility functions notebook here using `%run` notebook name `functions`

# COMMAND ----------

# MAGIC %run "/Shared/Pyspark_Project_Dynamic/utils/functions"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Calling Common utility `Pyspark Schema` notebook here using `%run` notebook name `pyspark_schema`

# COMMAND ----------

# MAGIC %run "/Shared/Pyspark_Project_Dynamic/utils/pyspark_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Creating parameters using `widgets` function `func_create_widgets((list))`
# MAGIC #### This is onetime activity

# COMMAND ----------

func_create_widgets(("landing_zone_file_path","landing_zone_folder_name","landing_zone_file_name","landing_zone_file_type","staging_zone_database_name","staging_zone_table_name","staging_zone_table_pk_column","pyspark_schema","job_name","job_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Defining Custom Schema while Reading file and creating dataframe.
# MAGIC * `inferSchema` is a costly operation. we should not use this on big data files. for creating datatypes it will read full data and dump into driver node.
# MAGIC * To avoid that load on `Driver Node` we are going to use `Customer Schema Defination using pyspark.sql.types`

# COMMAND ----------

# MAGIC %md
# MAGIC #### Get pyspark metadata (pyspark schema) at dynamically

# COMMAND ----------

#v_pyspark_schema = getArgument("pyspark_schema")
v_schema = globals()[pyspark_schema]()
v_schema

# COMMAND ----------

"""
if pyspark_schema=='channels_schema':
  pyspark_schema =channels_schema
elif pyspark_schema=='countries_schema':
  pyspark_schema =countries_schema
elif pyspark_schema=='customers_schema':
  pyspark_schema =customers_schema
elif pyspark_schema=='product_schema':
  pyspark_schema =product_schema
elif pyspark_schema=='promotions_schema':
  pyspark_schema =promotions_schema
elif pyspark_schema=='times_schema':
  pyspark_schema =times_schema
elif pyspark_schema=='sales_schema':
  pyspark_schema =sales_schema
elif pyspark_schema=='costs_schema':
  pyspark_schema =costs_schema
else:
  pass
"""

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Get full path from joining individual variables
# MAGIC * `import os` module and use `join`

# COMMAND ----------

import os
full_path = os.path.join(landing_zone_file_path,landing_zone_folder_name,landing_zone_file_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading Source .csv files and creating dataframe.
# MAGIC * we are using `read_csv` function for reading files and creating `dataframe`
# MAGIC * we are using `Try and Exception` block to track if any errors at runtime.

# COMMAND ----------

try:
    
    df_staging_csv = func_read_csv(full_path+'*.csv',v_schema)
except Exception as e:
    func_register_log("ERROR", "Error counting logs from uploaded files:"+str(sys.exc_info()[1]))
    func_register_log ("ERROR", "Error counting logs from uploaded files:"+str(e))    
    
    raise dbutils.notebook.exit(json.dumps({"status":"FAILED","error":str(e)}))

# COMMAND ----------

# Number of rows and columns per uploaded file
try:
  landingRows, landingColumns = df_staging_csv.count(),len(df_staging_csv.columns)
except Exception as e:
  func_register_log ("ERROR", "Error counting logs from uploaded files:" + str(sys.exc_info()[1]))
  raise dbutils.notebook.exit(json.dumps({"status":"FAILED","error":str(e)})) #raise the exception
finally:
  func_register_log ("INFO", f"Status file: number of rows for {landing_zone_folder_name} : {landingRows}, number of columns: {landingColumns}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Adding adition columns into `Dataframe`
# MAGIC * below command we are going to create two aditional two columns in `dataframe`
# MAGIC * `Key Column` which is generated using `md5` based on `Id Column` from source table
# MAGIC * Adding `load_date` column and inserting `current_timestamp()`

# COMMAND ----------

try:
  df_staging_csv = func_add_audit_cols(df_staging_csv)
  
  print('adding audit columns to staging dataframe is completed')
except Exception as e:
  func_register_log ("ERROR", "Error While adding audit columns:" + str(sys.exc_info()[1]))
  raise dbutils.notebook.exit(json.dumps({"status":"FAILED","error":str(e)})) #raise the exception

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Creating `DataFrame` from target table data based on `single ID Column`
# MAGIC * we are using below command to get existing data from target table to compare incremental data from source.

# COMMAND ----------

# Since Spark 2.3, the queries from raw JSON/CSV files are disallowed when the referenced columns only include the internal corrupt record column (named _corrupt_record by default).
# For example: spark.read.schema(schema).csv(file).filter($"_corrupt_record".isNotNull).count() and spark.read.schema(schema).csv(file).select("_corrupt_record").show().
# Instead, you can cache or save the parsed results and then send the same query.
# Remove corrupt records
try:
  df_staging_csv.cache()
  bad_rows = df_staging_csv.select("_corrupt_record","input_file_name","UPDATED_DATE").filter(df_staging_csv._corrupt_record.isNotNull())
  bad_rows.write.format("delta").mode("append").option("mergeSchema","true").saveAsTable("log_db.job_bad_data_log")
  # Filter out bad records  
  bad_rowcount = bad_rows.count()
  
  # logging bad rows
  func_register_log("INFO", "No Of _corrupt_reocrd rows : {} in table {}".format(bad_rowcount,staging_zone_table_name))
  df_staging_csv = df_staging_csv.filter((col("_corrupt_record").isNull())).drop("_corrupt_record","input_file_name")
  df_staging_csv.unpersist()
  print('Data validation completed - bad rows : {} - '.format(bad_rowcount))
  
except Exception as e:
  func_register_log("ERROR", "Error While removing _corrupt_reocrd :" + str(sys.exc_info()[1]))
  raise dbutils.notebook.exit(json.dumps({"status":"FAILED","error":str(e)})) #raise the exception
##df_channels.createOrReplaceTempView('df_channels_v')
##df_channels_old = spark.sql('select channel_id from  sales.channels')

# COMMAND ----------

try:
  df_staging_csv.write.mode("overwrite").saveAsTable(staging_zone_database_name +'.'+staging_zone_table_name )
  stg_rowcount=df_staging_csv.count()
  print('writing into staging load completed')
  print('Total no of rows written into staging table : {0}'.format(stg_rowcount))
except Exception as e:  
  func_register_log("ERROR", "Error While saving data into Staging table :" +str(sys.exc_info()[1])+" table Name : "+staging_zone_table_name)
  raise dbutils.notebook.exit(json.dumps({"status":"FAILED","error":str(e)})) #raise the exception

# COMMAND ----------

# Calling final Audit log function to append logs
func_final_log_append()

# COMMAND ----------

#dbutils.notebook.exit('SUCCESS')
import json
dbutils.notebook.exit(json.dumps({"landingRows":landingRows,"stagingRows":stg_rowcount,"rejectedRows":bad_rowcount,"jobName":job_name,"jobId":job_id, "status":"SUCCESS"}))