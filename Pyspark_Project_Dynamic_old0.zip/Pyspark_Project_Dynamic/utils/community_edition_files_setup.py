# Databricks notebook source
dbutils.fs.rm("/mnt/landing/sales",True)
dbutils.fs.mkdirs("/mnt/landing/sales")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/channels/channels06-12-2020-10-20-50.csv","/tmp/channels06-12-2020-10-20-50.csv")
dbutils.fs.mv("file:/tmp/channels06-12-2020-10-20-50.csv","dbfs:/mnt/landing/sales/channels/channels06-12-2020-10-20-50.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/countries/countries06-12-2020-10-20-50.csv","/tmp/countries06-12-2020-10-20-50.csv")
dbutils.fs.mv("file:/tmp/countries06-12-2020-10-20-50.csv","dbfs:/mnt/landing/sales/countries/countries06-12-2020-10-20-50.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/customers/customers06-12-2020-10-20-55.csv","/tmp/customers06-12-2020-10-20-55.csv")
dbutils.fs.mv("file:/tmp/customers06-12-2020-10-20-55.csv","dbfs:/mnt/landing/sales/customers/customers06-12-2020-10-20-55.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/product/product06-12-2020-10-20-11.csv","/tmp/product06-12-2020-10-20-11.csv")
dbutils.fs.mv("file:/tmp/product06-12-2020-10-20-11.csv","dbfs:/mnt/landing/sales/product/product06-12-2020-10-20-11.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/costs/costs06-12-2020-10-20-50.csv","/tmp/costs06-12-2020-10-20-50.csv")
dbutils.fs.mv("file:/tmp/costs06-12-2020-10-20-50.csv","dbfs:/mnt/landing/sales/costs_transaction/costs_transaction06-12-2020-10-20-50.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/promotions/promotions06-12-2020-10-20-44.csv","/tmp/promotions06-12-2020-10-20-44.csv")
dbutils.fs.mv("file:/tmp/promotions06-12-2020-10-20-44.csv","dbfs:/mnt/landing/sales/promotions/promotions06-12-2020-10-20-44.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/sales/sales06-12-2020-10-20-33.csv","/tmp/sales06-12-2020-10-20-33.csv")
dbutils.fs.mv("file:/tmp/sales06-12-2020-10-20-33.csv","dbfs:/mnt/landing/sales/sales_transaction/sales_transaction06-12-2020-10-20-33.csv")

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/times/times06-12-2020-10-20-13.csv","/tmp/times06-12-2020-10-20-13.csv")
dbutils.fs.mv("file:/tmp/times06-12-2020-10-20-13.csv","dbfs:/mnt/landing/sales/times/times06-12-2020-10-20-13.csv")

# COMMAND ----------

#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/costs/costs06-12-2020-10-20-50.csv
#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/countries/countries06-12-2020-10-20-50.csv
#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/customers/customers06-12-2020-10-20-55.csv
#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/product/product06-12-2020-10-20-11.csv
#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/promotions/promotions06-12-2020-10-20-44.csv
#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/sales/sales06-12-2020-10-20-33.csv
#https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/SH/times/times06-12-2020-10-20-13.csv

# COMMAND ----------

# MAGIC %fs ls /mnt/landing/