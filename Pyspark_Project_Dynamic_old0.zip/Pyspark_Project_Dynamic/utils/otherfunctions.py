# Databricks notebook source
def func_data_duplicate_check_log(df):
        """
        Aim: Takes main DataFrame and take seperate count unique and total counts.
        Input params: 
            total : Total Rows 
            unique : unique Rows
        return: None
        """
        logging.info('Performing Duplicate Data quality checks...')
        total=df.count()
        unique=df.dropDuplicates().count()
        if (total-unique)==0:
            logging.info("There is no Duplicates, quality check passsed")
            return True
        else:
            logging.info("Duplicates Found : {}  Duplicate Rows    ".format(total-unique) ) 
            return False
    
    # This Function will validate any NULL data columns in all fields...
    
    

# COMMAND ----------

def func_data_null_check_log(df):
        """Function returns results of null checks for each column and total rows in table
        Input:
            - title   : STRING, title of table
            - sparkdf : a spark dataframe
        """
        sparkdf_columns = df.columns
        total = df.count()
        logging.info(" ")
        logging.info('Performing quality checks for {}'.format(self.source))
        for colname in sparkdf_columns:
            null_values= df.filter(df[colname].isNull()).count()
            logging.info('Number of null values for {} is: {}'.format(colname, null_values))        
        logging.info('Total number of rows is: {}'.format(total))
        logging.info(" ")
        return True

# COMMAND ----------

from py4j.protocol import Py4JJavaError

def func_create_widgets(widgets):
  """ This function we are using for creating multiple wisgets.
      While moving code from one environment to other it wont be moved.
      So it should be created each environment.
      
      Import all the widgets listed in widgets, and create any missing ones
      Default to dbutils.widgets.text, with blank defaultvalue
  """
  
  for v in widgets:
    try:
      globals()[v] = dbutils.widgets.get(v)
    except Py4JJavaError:
      dbutils.widgets.text(v,"")
      globals()[v] = dbutils.widgets.get(v)
      
    except Exception as e:
      raise e

# COMMAND ----------

def func_remove_null_duplicate(df,pk):
        """Function returns results of null checks for each column and total rows in table
        Input:
            - title   : STRING, title of table
            - sparkdf : a spark dataframe
        """
        df = df.dropDuplicates(pk.split(","))
        df = df.fillna(0).fillna('EMPTY')
        
        
        return df

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
# ETL log record table schema
log_table_schema = StructType ([
  StructField ('created_date', TimestampType (), True),
  StructField ('log_type', StringType (), True),
  StructField ('log_description', StringType (), True)
  ])

# DataFrame with the ETL log record
df_log = spark.createDataFrame ([], log_table_schema)

# COMMAND ----------

# Function to record the process log
def func_register_log(log_type, log_description):
  """
  This function we can use for cutom logging using dataframe and table
  input Parameters:
  log_type: you can pass log type like ERROR , INFO, DATA-VALIDATION..
  log_description : log description like error message or row count .. duplicate data count...
  """
  from datetime import datetime
  values_to_register = [(datetime.now(),log_type,log_description)]
  newRow = spark.createDataFrame (values_to_register).toDF("created_date","log_type","log_description")
  
  global df_log
  df_log = df_log.union(newRow)
  #df_log.show()
  if log_type == "ERROR":    
    # Store the worked log in the dataframe in the final table
    df_log.write.format("delta").option("mergeSchema","true").mode("append").saveAsTable("log_db.job_audit_log")
    # Exit notebook execution
    dbutils.notebook.exit (log_description)
  else:
    df_log.write.format("delta").option("mergeSchema","true").mode("append").saveAsTable("log_db.job_audit_log")

# COMMAND ----------

# Function to support the EDA process, validating the total of null-voids per column
def func_validate_nulldata (type, df):
  """
  This function we can use for to validate null data in dataframe
  """
  try:
    #We count total of nulls and voids that exist per column
    # isnan(c) will work for non date datatypes. if you have any date datatype dont use isnan(c)
    # df.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df.columns]).show()
    dfEmptyColumns = df.select([count(when(col(c).isNull(), c)).alias(c) for c in df.columns])
    #We select only the columns that have null or empty
    dfEmptyColumns = dfEmptyColumns.select([key for (key,value) in dfEmptyColumns.collect()[0].asDict().items() if value> 0])
    #Register in the log
    for column,total in dfEmptyColumns.collect()[0].asDict().items():
      func_register_log("DATA-VALIDATION", f"Empty-Null file {type}, column: {column}, total: {total}")
  except:
    func_register_log("ERROR", "Error counting total nulls or voids per column of file {type}:"+str(sys.exc_info()[1]))

# COMMAND ----------

# Function to find duplicate records
def func_validate_duplicatedata(type, df):
  """
  This function for to validate dupliate rows in any dataframe.
  """  
  try:
    total = df.groupBy([c for c in df.columns]).count().filter("count > 1").count()
  except:
    func_register_log("ERROR", "Error counting total duplicate records in file {type}:"+str(sys.exc_info()[1]))
  else:
    func_register_log("DATA-VALIDATION",f'File duplicates {type}, total: {total}')

# COMMAND ----------

# Mongo credentials
def func_connect_mango(connection, database, collection):
    mongoHostname = connection['hostname']
    mongoPort = connection['port']
    mongoDatabase = database
    mongoCollection = collection
    mongoUsername = connection.get('username')
    mongoPassword = connection.get('password')
    mongoReplica = connection.get('replica')
    
    baseURI = "mongodb://"
    if bool(mongoUsername) and bool(mongoPassword):
        baseURI += f"{mongoUsername}:{mongoPassword}@"
    mongoHosts = ",".join([
        f"{host}:{mongoPort}"
        for host in mongoHostname.split(",")
    ])
    mongoURI = f"{baseURI}{mongoHosts}/{mongoDatabase}"
    if bool(mongoReplica):
        mongoURI = f"{mongoURI}.{mongoCollection}?replicaSet={mongoReplica}"
    else:
        mongoURI = f"{mongoURI}.{mongoCollection}"
    return mongoURI

# COMMAND ----------

# Postgres
def func_connect_postgres(connection):
    # Postgres credentials
    jdbcHostname = connection['host']
    jdbcPort = connection['port']
    jdbcDatabase = connection['database']
    dialect = connection['dialect']
    jdbcUsername = connection['username']
    jdbcPassword = connection['password']
    
    jdbcUrl = f"jdbc:{dialect}://{jdbcHostname}:{jdbcPort}/{jdbcDatabase}"
    # for mysql driver = com.mysql.jdbc.Driver
    connectionProperties = {
      "user" : jdbcUsername,
      "password" : jdbcPassword,
      "driver" : "org.postgresql.Driver" 
    }
    return (jdbcUrl, connectionProperties)

# COMMAND ----------

def func_records_perpartition(df):
  '''
  Utility method to count & print the number of records in each partition
  '''
  print("Per-Partition Counts:")
  
  def countInPartition(iterator): 
    yield __builtin__.sum(1 for _ in iterator)
    
  results = (df.rdd                   # Convert to an RDD
    .mapPartitions(countInPartition)  # For each partition, count
    .collect()                        # Return the counts to the driver
  )

  for result in results: 
    print("* " + str(result))

# COMMAND ----------

def func_get_count_by_partition(df):
  from pyspark.sql.functions import spark_partition_id
  '''
  Using spark_partition_id() function we can get partition id and get count on each partition using groupby
  '''
  print("Per-Partition Counts:")
  # Creating new column as partition_id using spark_partition_id() function
  df = df.withColumn("partition_id",spark_partition_id())
  # Taking count on each partition using groupBy("partition_id") and orderBy("partition_id")
  results = df.groupBy("partition_id").count().orderBy("partition_id")
  # Looping each partition count using for loop
  for a,b in results.collect(): 
    print("Partition id : {} And No Of Rows : {} ".format(a,b))

# COMMAND ----------

def func_gen_monotonically_id(df):
  from pyspark.sql.functions import monotonically_increasing_id
  '''
  Using spark_partition_id() function we can get partition id and get count on each partition using groupby
  '''
  print("Per-Partition Counts:")
  # Creating new column as partition_id using monotonically_increasing_id() function
  df = df.withColumn("KEY",monotonically_increasing_id())
  
  return df

# COMMAND ----------

def func_add_audit_cols(df):
  from pyspark.sql.functions import md5,col,concat,lit,current_timestamp
  '''
  Adding Audit columns in all dataframes before writing into table
  '''
  try:
    df = df.withColumn('CREATED_DATE',lit(current_timestamp()))\
              .withColumn('CREATED_BY',lit('ETLJOB'))\
              .withColumn('UPDATED_DATE',lit(current_timestamp()))\
              .withColumn('UPDATED_BY',lit('ETLJOB'))
  except Exception as e:
    func_register_log ("ERROR", "Error While adding audit columns:" + str(sys.exc_info()[1]))
    raise dbutils.notebook.exit(e) #raise the exception
  
  return df

# COMMAND ----------

def func_delete_tables(db) :
  """
  Drop all tables from database specific
  """
  try:
    tables=spark.catalog.listTables(db)
  except:
    return
  for table in tables:
      spark.sql("DROP TABLE {}.{}".format(db, table.name))
      print("DROPPED TABLE {}.{}".format(db, table.name))
      
# deleteTables()

# COMMAND ----------

def flatten_structs(nested_df):
  """
  this function we can use for identifying nested data types like  ARRAY and STRUCT type fields and 
  Creating individual datatypes with underscore _ 
  input Param:  Pyspark Dataframe
  
  """
    # Creating python list to store dataframe metadata
  stack = [((), nested_df)]
    # Creating empty python list for storing identified nested data type columns information
  columns = []

  while len(stack) > 0:
      # Removing latest or recently added item (dataframe schema) and returning into df variable  
      parents, df = stack.pop()
      # Reading data types one by one using loop and validating array type and getting those  
      array_cols = [  c[0]  for c in df.dtypes   if c[1][:5] == "array"  ]
      
      # 
      flat_cols = [  f.col(".".join(parents + (c[0],))).alias("_".join(parents + (c[0],)))
            for c in df.dtypes
            if c[1][:6] != "struct"   ]
      
      nested_cols = [  c[0]   for c in df.dtypes if c[1][:6] == "struct"   ]
      # appending all columns
      
      columns.extend(flat_cols)
      #Reading  nested columns and appending into stack list
      
      for nested_col in nested_cols:
            projected_df = df.select(nested_col + ".*")
            stack.append((parents + (nested_col,), projected_df))
            
      
      
  return nested_df.select(columns)

# COMMAND ----------

def flatten_array_struct_df(df):
  """
  Using this function reading all nested columns and converting into normal columns.
  """
    # getting no of array columns for looping
  array_cols = [  c[0]   for c in df.dtypes  if c[1][:5] == "array"   ]
    
  while len(array_cols) > 0:
        
      for array_col in array_cols:            
        cols_to_select = [x for x in df.columns if x != array_col ] 
        # Using Explode function flattening the data
        df = df.withColumn(array_col, f.explode(f.col(array_col)))
      # calling above function to update latest fields. 
      
      df = flatten_structs(df)
      
      # reducing number based latest updated columns
      array_cols = [   c[0]  for c in df.dtypes    if c[1][:5] == "array"     ]
        
  return df



# COMMAND ----------

def func_convert_pyspark_schema(df):
  from pyspark.sql.types import StructField,IntegerType,StringType,DoubleType,StructField
  """
  using this function we can convert to pyspark Schema
  """  
  
  def strToType(str):
    """ 
    Using this function to validate individual datatype and if it is string by default it will considar StringType() 
    """
    if str == 'int':
      return IntegerType()
    elif str == 'double':
      return DoubleType()
    else:
      return StringType()
  # Creating pyspark Schema
  pyspark_schema = StructType([StructField(t[0], strToType(t[1]), True) for t in df.dtypes])
  return pyspark_schema


# COMMAND ----------

from pyspark.sql.functions import regexp_replace, trim, col, lower
def removePunctuation(column):
    """Removes punctuation, changes to lower case, and strips leading and trailing spaces.

    Note:
        Only spaces, letters, and numbers should be retained.  Other characters should should be
        eliminated (e.g. it's becomes its).  Leading and trailing spaces should be removed after
        punctuation is removed.

    Args:
        column (Column): A Column containing a sentence.

    Returns:
        Column: A Column named 'sentence' with clean-up operations applied.
    """
    return trim(regexp_replace(lower(column), '[^a-zA-Z||\s||^0-9]', ''))

# COMMAND ----------

def parse_clf_time(s):
    """ Convert Common Log time format into a Python datetime object
    Args:
        s (str): date and time in Apache time format [dd/mmm/yyyy:hh:mm:ss (+/-)zzzz]
    Returns:
        a string suitable for passing to CAST('timestamp')
    """
    # NOTE: We're ignoring time zone here. In a production application, you'd want to handle that.
    return "{0:04d}-{1:02d}-{2:02d} {3:02d}:{4:02d}:{5:02d}".format(
      int(s[7:11]),
      month_map[s[3:6]],
      int(s[0:2]),
      int(s[12:14]),
      int(s[15:17]),
      int(s[18:20])
    )

# COMMAND ----------

import unicodedata
def strip_accents(s):
    if not s : 
        return s
    return s.encode('ascii', 'ignore').decode('ascii')

# COMMAND ----------

def func_read_synapse(spark, config):
        drivers = {"mssql": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
        return spark.read.format("jdbc") \
            .option("url", f"jdbc:sqlserver://{eval(config)['host']}:{eval(config)['port']};databaseName={eval(config)['database']}") \
            .option(eval(config)['qtype'], eval(config)['query']) \
            .option("user", eval(config)['user']) \
            .option("password", eval(config)['password']) \
            .option("driver",  "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .load()

# COMMAND ----------

def func_write_synapse(df, spark, config):
        drivers = {"mssql": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
        # Write modes: overwrite, append
        df.write.mode(eval(config)['writemode'])\
            .format('jdbc') \
            .option("url", f"jdbc:{eval(config)['dbtype']}://{eval(config)['host']}:{eval(config)['port']};databaseName={eval(config)['database']}") \
            .option("dbtable", eval(config)['table']) \
            .option("user", eval(config)['user']) \
            .option("password", eval(config)['password']) \
            .option("driver",  "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .save()

# COMMAND ----------

def func_drop_columns(df,cols):
    for col in cols:
        df = df.drop(col)
    return df;

# COMMAND ----------

def getNonNumericColumns(df):
    attributeNames = [];
    for col in df.columns:
        if (df[col].dtype != 'int64') and (df[col].dtype != 'float64'):
            attributeNames.append(col);
    return attributeNames;

# COMMAND ----------

# Convert all missing values in the specified column to the default
def missing_default(df, col, default_value):
  
    df[col] = df[col].fillna(default_value)
    return df

# COMMAND ----------

# Convert all missing values in the specified column to the median
def missing_median(df, col):
    med = df[col].median()
    df[col] = df[col].fillna(med)
    return df

# COMMAND ----------

def divide_columns(df_X) :
    columns = list(df_X.columns)

    num_columns = []
    cat_columns = []

    for column in columns :
        if df_X[column].dtypes == 'object' :
            cat_columns.append(column)

        else :
            num_columns.append(column)

    return num_columns, cat_columns

# COMMAND ----------

def func_rename_multi_files():
  #Create variables
  table_name = dbutils.widgets.get("table_name") # getting table name
  filePath = "dbfs:/mnt/datalake/" + table_name + "/" # path where original csv file name is located
  newfilename = table_name + ".txt" # transforming csv into txt
  curatedfilePath = "dbfs:/mnt/datalake/" + newfilename # curated path + new file name

  #Save CSV file
  df_curated.coalesce(1).replace("", None).write.mode("overwrite").save(filePath,format='csv', delimiter='|', header=True, nullValue=None)

  # getting original csv file name
  for f in filePath:
              if f[1].startswith("part-00000"): 
                   original_file_name = f[1]

  #move to curated folder
  dbutils.fs.mv(filePath + fileName, curatedfilePath)

# COMMAND ----------

# Errors in workflows thrown a WorkflowException.
def run_with_retry(notebook, timeout, args = {}, max_retries = 3):
  """
  Handle errors
  This section illustrates how to handle errors in notebook workflows.
  """
  num_retries = 0
  while True:
    try:
      return dbutils.notebook.run(notebook, timeout, args)
    except Exception as e:
      if num_retries > max_retries:
        raise e
      else:
        print("Retrying error", e)
        num_retries += 1

#run_with_retry("LOCATION_OF_CALLEE_NOTEBOOK", 60, max_retries = 5)

# COMMAND ----------

#Deleting 3 months old data from blob storage
def func_delete_old_data():
  """
  Deleting 3 months old data from blob storage
  """
  import datetime
  import os
  from dateutil.relativedelta import relativedelta
  today=datetime.date.today()
  #print(today)
  d1 = today.strftime("%d%m%Y")
  #print(d1)
  month_ago=today+relativedelta(months=-3)
  #print(month_ago)
  d2 = month_ago.strftime("%d%m%Y")
  print(d2)

# COMMAND ----------

# Renaming the stored part files into required data format and moving the data to date folder
def func_rename_all_files():
  #/mnt/osm/newjsonfiles/
  import os
  import shutil
  from datetime import date
  today = date.today()
  d1 = today.strftime("%d%m%Y")
  path="/dbfs"+tempblobpath
  src_files = os.listdir(path)
  i = 0
  for file_name in src_files:
      dst = "osm_" + d1 + "_part-" + str(i) + ".json"
      full_file_name = os.path.join(path, file_name)
      if os.path.isfile(full_file_name):
          shutil.move(full_file_name,tagpath+"/" + dst)
      i+=1

# COMMAND ----------

def func_create_datefolder():
  import os 

  from datetime import date
  today = date.today()
  d1 = today.strftime("%d%m%Y")
  tagpath = "/dbfs"+jsonblobpath+d1
  if os.path.isdir(tagpath):
     print ("File exist")
  else:    
     os.mkdir(tagpath)
  print(tagpath)

# COMMAND ----------

class ConfigClass(object):
    """ConfigClass will process the preprocess configuration functions.
    mountStorageContainer()
    load_yaml() configuration file.
    """
    def __init__(self, bloburl,mountpoint,config):
        """Constructor for new DataSourceJsonizer class
        Args:
            bloburl: Azure Storage Account Name with Container full URL
            mountpoint: Mount Point Path or location
            config : Azuer Blob Storage Account With Account KEY.."""
        self.bloburl    = bloburl
        self.mountpoint = mountpoint
        self.config     = config  
    def mountStorageContainer(self):
      """
      Aim: Mounting Azure Blob storage account with accessing path or Container using below three parameters.
      Input params: 
        bloburl : Azure Storage Account Name with Container full URL
        mountpoint :  Mount Point Path or location
        config:  Azuer Blob Storage Account With Account KEY..
      return: success status.
      """
      try : 
        dbutils.fs.mount(
          source = self.bloburl,
          mount_point = self.mountpoint,
           extra_configs =  self.config)
       #print("Storage Mounted.")
      except Exception as e:
        if "Directory already mounted" in str(e):
            pass   # Ignore error if already mounted.
        else:
            raise e
             
      return "Successfully Mounted."

# COMMAND ----------

def func_partition_wise_rowcount(df):
  """
  we can get no of partititions on dataframe using spark_partition_id function...
  """
  from pyspark.sql.functions import spark_partition_id
  df_part = df.withColumn("partition_id",spark_partition_id()).groupBy("partition_id").count()
  return df_part

# COMMAND ----------

def func_add_filename(df):
  """
  we can get file name into new column using input_file_name() function...
  """
  from pyspark.sql.functions import input_file_name
  df = df.withColumn("file_name",input_file_name())
  return df

# COMMAND ----------

def func_file_wise_rowcount(df):
  """
  we can get no of rows at each data file from dataframe using input_file_name() function...
  """
  from pyspark.sql.functions import input_file_name
  df_file = df.withColumn("file_name",input_file_name()).groupBy("file_name").count()
  return df_file

# COMMAND ----------

import logging
def func_log_error(func):
  """
  logging function to log error messages and information in table using this logging function
  """
  def no_error(*args, **kwargs):
      try:
          return func(*args, ** kwargs)
      except Exception as e:
          logging.error(str(e))
          return None
  return no_error

# COMMAND ----------

def func_get_all_dataframes():
  """
  This function we can use for to get all available dataframes in a list using 'globals().items()'
  """
  from pyspark.sql import DataFrame
  allDataFrames = [k for (k, v) in globals().items() if isinstance(v, DataFrame)]
  
  return allDataFrames

# COMMAND ----------

def func_remove_quotes(s):
    """ Remove quotation marks from an input string
    Args:
        s (str): input string that might have the quote "" characters
    Returns:
        str: a string without the quote characters
    """
    return ''.join(i for i in s if i!='"')

# COMMAND ----------

def func_create_ddl_backup(path):
  """
  this function we can use for creating delta lake or spark sql database tables backups.
  argument : path - you can pass storage location 
  in databricks we have to give /foldername/ bcz python file can create outside dbfs file
  call function : func_create_ddl_backup("/tmp/ddls/")
  """
  dbs = spark.catalog.listDatabases()
  for db in dbs:
    f = open("{}bkp_{}.sql".format(path,db.name), "w")
    tables = spark.catalog.listTables(db.name)
    for t in tables:
      DDL = spark.sql("SHOW CREATE TABLE {}.{};".format(db.name, t.name))
      f.write(DDL.first()[0])
      f.write("\n")
    f.close()

# COMMAND ----------

def func_get_db_table_cols():
  list=[]
  for dbs in spark.catalog.listDatabases(): 
    for tables in spark.catalog.listTables(dbs.name):      
      for columns in spark.catalog.listColumns(tables.name,dbs.name):
        list.append([dbs.name,tables.name,columns.name])
  return list

# COMMAND ----------

def func_get_db_table_cols_inlist():
  list=[]
  cols=[]
  for dbs in spark.catalog.listDatabases():
    for tables in spark.catalog.listTables(dbs.name):      
      for columns in spark.catalog.listColumns(tables.name,dbs.name):
        cols.append(columns.name) 
        #print('database {} : tableNmae {}  : Columns : {}'.format(t.name,db.name,columns.name))
      list.append([dbs.name,tables.name,cols])
      
  return list

# COMMAND ----------


def func_verify_df(df):
  """
  Verify if dataframe is available or not
  """
  if not isinstance(df, DataFrame):
    raise ValueError("df parameter must be a DataFrame")

# COMMAND ----------

def remove_duplicate_cols(df):
  """
  Removing duplicate columns from dataframe.
  """
    unique_cols = []
    duplicate_cols = []

    for i in range(len(df.columns)):
        if df.columns[i] not in unique_cols:
            unique_cols.append(df.columns[i])
        else:
            duplicate_cols.append(i)

    df = df.toDF(*[str(i) for i in range(len(df.columns))])
    for dupcol in duplicate_cols:
        df = df.drop(str(dupcol))

    return df.toDF(*unique_cols)

# COMMAND ----------

def rename_cols(df):
    for column in df.columns:
        new_column = column.replace('.','_')
        df = df.withColumnRenamed(column, new_column)
    return df
  
  
#(df.select(*[F.col(c).alias(c.replace('.',"_")) for c in df.columns]))
#df.toDF(*(c.replace('.', '_') for c in df.columns))
#import re
#df.toDF(*(re.sub(r'[\.\s]+', '_', c) for c in df.columns))

# COMMAND ----------

def unzip_file(data_path, extract_path):
  """
  unzip files dynamically specifying source path and destination path
  """
    if not os.path.isfile(data_path):
        return "File does not exist"
    with ZipFile(data_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
        return 'File extracted'

# COMMAND ----------

from os.path import basename
from email.mime.application import MIMEApplication
from email import encoders
from email.mime.base import MIMEBase

def send_email_attachedment(Subject, toaddr, path, file, body_text):
  """
  we can use this function to send email with attachment.
  arguments:
  Subject: email subject
  toaddr: to email address
  path : path for datafile
  file: filename 
  body_text: email body context
  """
    fromaddr = "youer@email.com"

    msg = MIMEMultipart()
      
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = Subject
    BodyMail = msg.as_string()
    
    mail_file = MIMEBase('application', 'csv')
    mail_file.set_payload(open(path + file, 'rb').read())
    mail_file.add_header('Content-Disposition', 'attachment', filename=file)
    encoders.encode_base64(mail_file)
    msg.attach(mail_file)
    msg.attach(MIMEText(body_text))
    
    server = smtplib.SMTP(SMTPServer, 25)
    server.login(SMTPUser, SMTPPwd)
    server.sendmail(fromaddr, toaddr, msg.as_string())

# COMMAND ----------

def write_csv(path, filename, df, *delimit):
  """Store Data frame as a single CSV file

  :path: file path
  :filename: file name
  :df: dataframe
  :delimit: (OPTIONAL) delimiter used as separator for the CSV file 
  """
  
  if len(delimit) == 1 and delimit[0] == ";":
    df.repartition(1).write.format('csv'). ('overwrite').option("header", "true").option("delimiter", ";")\
    .option("emptyValue", None).option("nullValue", None).save(path+filename)
  elif len(delimit) == 1 and delimit[0] == "|":
    df.repartition(1).write.format('csv').mode('overwrite').option("header", "true").option("delimiter", "|")\
    .option("emptyValue", None).option("nullValue", None).save(path+filename)
  else:
    df.repartition(1).write.format('csv').mode('overwrite').option("header", "true").option("delimiter", ",")\
    .option("emptyValue", None).option("nullValue", None).save(path+filename)  