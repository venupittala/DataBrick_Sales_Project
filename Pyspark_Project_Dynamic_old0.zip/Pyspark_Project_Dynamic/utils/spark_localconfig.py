# Databricks notebook source
# MAGIC %md
# MAGIC #### Configure below environment if you are running in local environemnts....
# MAGIC * Below configuration is not required for `Azure Databricks`
# MAGIC * In Azure Databaricks `spark` session variable is available by default 
# MAGIC * In Azure Databricks `sc` SparkContext variable is available by default.

# COMMAND ----------

#spark context variable
#Note: in databricks sparkSession (spark) ,sparkContext(sc),sqlcontext and hivecontext are available default.
sc

# COMMAND ----------

#install pyspark module
!pip install pyspark

# COMMAND ----------

#install findspark for spark intialization 
!pip install findspark

# COMMAND ----------

#### Importing findspark and intializing findspark...

# COMMAND ----------

#intialize finspark using init() method
import findspark
findspark.init()
#findspark.init(SPARK_HOME)

# COMMAND ----------

#### Creating Spark Session

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder\
.master("local")\
.appName("Localspark")\
.getOrCreate()

# COMMAND ----------

#spark session variabl
spark

# COMMAND ----------

"""
from pyspark.sql import SparkSession
#spark = SparkSession.builder\
#.master("local".format(2))\
#.appName("Localspark")\
#.getOrCreate()

n_cpu = 2
spark = SparkSession.builder.appName('localSpark')\
.master('local[{}]'.format(n_cpu))\
.config("spark.driver.memory", "1g")\
.config('spark.executor.memory', '2g')\
.config('spark.executor.cores', '3')\
.config('spark.cores.max', '3')\
.getOrCreate()
"""

# COMMAND ----------

spark

# COMMAND ----------

from pyspark import SparkContext

sc = SparkContext.getOrCreate()

sc

# COMMAND ----------

# MAGIC %md
# MAGIC * Stop SparkContext And SparkSession using stop() method.

# COMMAND ----------

#stop spark session
#spark.stop()
# stop SparkContext
#sc.stop()

# COMMAND ----------

sc

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setting spark Memory parameters Configuration....

# COMMAND ----------

""" 
conf = spark.sparkContext._conf.setAll([('spark.executor.memory', '4g'), ('spark.app.name', 'Spark Updated Conf'), ('spark.executor.cores', '4'), ('spark.cores.max', '4'), ('spark.driver.memory','2g')])
"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Verify All Configuration parameter values

# COMMAND ----------

#Get all configuration 
sc.getConf().getAll()

# COMMAND ----------

#Get all configuration 
spark.sparkContext._conf.getAll()

# COMMAND ----------

spark.sparkContext.applicationId

# COMMAND ----------

sc._jsc.sc().applicationId()

# COMMAND ----------

# A contiguous collection of these blocks constitutes a partition. For example HDSF block size: 128 MB
# Size of partitions: spark.sql.files.maxPartitionBytes

# COMMAND ----------

#spark.conf.set("spark.sql.files.maxPartitionBytes","100M")
# partition size
print(spark.conf.get("spark.sql.files.maxPartitionBytes"))
# suffle partitions count
print(spark.conf.get("spark.sql.shuffle.partitions"))
#spark.conf.set("spark.sql.shuffle.partitions","200")

# COMMAND ----------

print(sc.version) # Retrieve SparkContext version
print(sc.pythonVer) # Retrieve Python version
print(sc.master) # Master URL to connect to
print(str(sc.sparkHome)) # Path where Spark is installed on worker nodes
print(str(sc.sparkUser()))# Retrieve name of the Spark User running SparkContext
print(sc.appName) # Return application name
print(sc.applicationId) # Retrieve application ID
print(sc.defaultParallelism)# Return default level of parallelism
print(sc.defaultMinPartitions) # Default minimum number of partitions for

# COMMAND ----------

# MAGIC %md
# MAGIC #### Get All Spark Configuration using `sparkContext(sc).getConf().getAll()`

# COMMAND ----------

sc.getConf().getAll()

# COMMAND ----------

from pyspark.sql import SparkSession 
from pyspark import SparkContext
from pyspark.conf import SparkConf
conf = spark.sparkContext._conf.setAll([('spark.executor.memory', '3g'), 
                                        ('spark.app.name', 'Spark Updated Conf'), 
                                        ('spark.executor.cores', '2'), 
                                        ('spark.cores.max', '4'), 
                                        ('spark.driver.memory','9g')])


sc.stop()

sc = pyspark.SparkContext(conf=conf)

# COMMAND ----------

sc.getConf().getAll()