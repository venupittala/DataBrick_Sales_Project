# Databricks notebook source
# MAGIC %md
# MAGIC ## Please Run Command By Command One after another
# MAGIC ### First Dimensions Then Facts.

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from jobs.JOB_LIST_DYNAMIC where job_status=1 and table_type='fact' order by id asc

# COMMAND ----------

from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ### Country notebook with parameters

# COMMAND ----------

# MAGIC %run "./NB_sales_load_dynamic" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="countries" $landing_zone_file_name="countries" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_countries" $staging_zone_table_pk_column="COUNTRY_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_countries" $curation_zone_table_pk_column="COUNTRY_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="dim_countries" $dw_zone_table_pk_column="COUNTRY_KEY" $pyspark_schema="countries_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Customers notebook with parameters

# COMMAND ----------

# MAGIC %run "./NB_sales_load_dynamic" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="customers" $landing_zone_file_name="customers" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_customers" $staging_zone_table_pk_column="CUST_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_customers" $curation_zone_table_pk_column="CUST_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="dim_customers" $dw_zone_table_pk_column="CUST_KEY" $pyspark_schema="customers_schema"

# COMMAND ----------

spark.catalog.clearCache()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product notebook with parameters

# COMMAND ----------

# MAGIC %run "./NB_sales_load_dynamic" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="product" $landing_zone_file_name="product" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_product" $staging_zone_table_pk_column="PROD_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_product" $curation_zone_table_pk_column="PROD_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="dim_product" $dw_zone_table_pk_column="PROD_KEY" $pyspark_schema="product_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Channel notebook with parameters

# COMMAND ----------

# MAGIC %run "/Shared/Pyspark_Project_Dynamic/NB_sales_load_dynamic" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="channels" $landing_zone_file_name="channels" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_channels" $staging_zone_table_pk_column="CHANNEL_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_channels" $curation_zone_table_pk_column="CHANNEL_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="dim_channels" $dw_zone_table_pk_column="CHANNEL_KEY" $pyspark_schema="channels_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Promotions notebook with parameters

# COMMAND ----------

# MAGIC %run "./NB_sales_load_dynamic" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="promotions" $landing_zone_file_name="promotions" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_promotions" $staging_zone_table_pk_column="PROMO_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_promotions" $curation_zone_table_pk_column="PROMO_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="dim_promotions" $dw_zone_table_pk_column="PROMO_KEY" $pyspark_schema="promotions_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Times notebook with parameters

# COMMAND ----------

# MAGIC %run "./NB_sales_load_dynamic" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="times" $landing_zone_file_name="times" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_times" $staging_zone_table_pk_column="TIME_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_times" $curation_zone_table_pk_column="TIME_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="dim_times" $dw_zone_table_pk_column="TIME_KEY" $pyspark_schema="times_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Costs notebook with parameters

# COMMAND ----------

# MAGIC 
# MAGIC %run "./NB_sales_landing_staging" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="costs_transaction" $landing_zone_file_name="costs" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_costs_transaction" $staging_zone_table_pk_column="PROD_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_costs_transaction" $curation_zone_table_pk_column="PROD_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="fact_costs_transaction" $dw_zone_table_pk_column="COST_FACT_KEY" $pyspark_schema="costs_schema"

# COMMAND ----------

# MAGIC %run "./NB_costs_fact_load" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="costs_transaction" $landing_zone_file_name="costs" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_costs_transaction" $staging_zone_table_pk_column="PROD_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_costs_transaction" $curation_zone_table_pk_column="PROD_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="fact_costs_transaction" $dw_zone_table_pk_column="COST_FACT_KEY" $pyspark_schema="costs_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sales notebook with parameters

# COMMAND ----------

# MAGIC %run "./NB_sales_landing_staging" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="sales_transaction" $landing_zone_file_name="sales" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_sales_transaction" $staging_zone_table_pk_column="PROD_ID,CUST_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_sales_transaction" $curation_zone_table_pk_column="PROD_ID,CUST_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="fact_sales_transaction" $dw_zone_table_pk_column="SALES_FACT_KEY" $pyspark_schema="sales_schema"

# COMMAND ----------

# MAGIC %run "./NB_sales_fact_load" $landing_zone_file_path="/mnt/landing/sales" $landing_zone_folder_name="sales_transaction" $landing_zone_file_name="sales" $landing_zone_file_type="csv" $staging_zone_database_name="stg_sales" $staging_zone_table_name="stg_sales_transaction" $staging_zone_table_pk_column="PROD_ID,CUST_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $curation_zone_database_name="curation_sales" $curation_zone_table_name="curation_sales_transaction" $curation_zone_table_pk_column="PROD_ID,CUST_ID,TIME_ID,CHANNEL_ID,PROMO_ID" $dw_zone_database_name="dw_sales" $dw_zone_table_name="fact_sales_transaction" $dw_zone_table_pk_column="SALES_FACT_KEY" $pyspark_schema="sales_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Verify BAd Data in below query

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*),updated_Date from log_db.job_bad_data_log where input_file_name like '%channels%' group by updated_Date

# COMMAND ----------

# MAGIC %md
# MAGIC ### Verify Audit log and validations information in below table

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from log_db.job_audit_log

# COMMAND ----------

# MAGIC %md
# MAGIC # Below code for Enterprise Edition

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Getting data from common job config table `jobs.job_list_dynamic`

# COMMAND ----------

df_jobs_list = spark.sql("select * from jobs.JOB_LIST_DYNAMIC where job_status=1 and table_type='dim' order by id asc")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Processing dynamically all notebooks using `job config` table with `dbutils.notebook.run()`

# COMMAND ----------

for load in df_jobs_list.rdd.collect():
  dbutils.notebook.run("NB_sales_load_dynamic",timeout_seconds=6000,arguments={"landing_zone_file_path":load["landing_zone_file_path"],"landing_zone_folder_name":load["landing_zone_folder_name"],"landing_zone_file_name":load["landing_zone_file_name"],"landing_zone_file_type":load["landing_zone_file_type"],"staging_zone_database_name":load["staging_zone_database_name"],"staging_zone_table_name":load["staging_zone_table_name"],"staging_zone_table_pk_column":load["staging_zone_table_pk_name"],"curation_zone_database_name":load["curation_zone_database_name"],"curation_zone_table_name":load["curation_zone_table_name"],"curation_zone_table_pk_column":load["curation_zone_table_pk_name"],"dw_zone_database_name":load["dw_zone_database_name"],"dw_zone_table_name":load["dw_zone_table_name"],"dw_zone_table_pk_column":load["dw_zone_table_pk_column"],"pyspark_schema":load["pyspark_schema"]})

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dw_sales.dim_countries

# COMMAND ----------

from datetime import datetime

today = datetime.now()
today.strftime('%Y-%m-%d')