# Databricks notebook source
# MAGIC %md
# MAGIC ## SQL Data Warehouse Pre-Requisites

# COMMAND ----------

# MAGIC %md
# MAGIC There are two pre-requisites for connecting Azure Databricks with SQL Data Warehouse that apply to the SQL Data Warehouse:
# MAGIC 1. You need to [create a database master key](https://docs.microsoft.com/en-us/sql/relational-databases/security/encryption/create-a-database-master-key) for the Azure SQL Data Warehouse. 
# MAGIC 
# MAGIC     **The key is encrypted using the password.**
# MAGIC 
# MAGIC     USE [databricks-sqldw];  
# MAGIC     GO  
# MAGIC     CREATE MASTER KEY ENCRYPTION BY PASSWORD = '980AbctotheCloud427leet';  
# MAGIC     GO
# MAGIC 
# MAGIC 2. You need to ensure that the [Firewall](https://docs.microsoft.com/en-us/azure/sql-database/sql-database-firewall-configure#manage-firewall-rules-using-the-azure-portal) on the Azure SQL Server that contains your SQL Data Warehouse is configured to allow Azure services to connect (e.g., Allow access to Azure services is set to On).
# MAGIC 
# MAGIC You should have already completed the above requirements in earlier steps of the lab.

# COMMAND ----------

# MAGIC %sql
# MAGIC --- run below command azure synapse dedicated sql pool
# MAGIC CREATE MASTER KEY ENCRYPTION BY PASSWORD = '2398732kjsdfj23sfksdf';
# MAGIC GO

# COMMAND ----------

# MAGIC %md
# MAGIC You can enable access for the lifetime of your notebook session to SQL Data Warehouse by executing the cell below. Be sure to replace the **"name-of-your-storage-account"** and **"your-storage-key"** values with your own before executing.

# COMMAND ----------

# Databricks notebook source
# Set credentials for blob storage 
spark.conf.set("fs.azure.account.key.adlsgen2pysparks.blob.core.windows.net", "XAoMh9TWwe1LQSVr2mWrpDVEPi99eyImc0t/ZEBtO0xbGXe02b94ZBsdsdtS7SxYvkJidoLBDkklhXaeXBcjyqtVjg==")

# COMMAND ----------

sc._jsc.hadoopConfiguration().set(
  "fs.azure.account.key.adlsgen2pysparks.blob.core.windows.net",
  "XAoMh9TWwe1LQSVr2mWrpDVEPi99eyImc0t/ZEBtO0xbGXe02sdsdZBtS7SxYvkJidoLBDkklhXaeXBcjyqtVjg==")

# COMMAND ----------

# MAGIC %md
# MAGIC You will need the JDBC connection string for your Azure SQL Data Warehouse. You should copy this value exactly as it appears in the Azure Portal. 
# MAGIC 
# MAGIC Please replace the missing **`servername`**, **`databasename`**, and **`your-password`** values in the command below:

# COMMAND ----------

username = "pysparkadmin" # AAD user with READ permission on database
password = "password"

jdbcString = ("jdbc:sqlserver://pysparksqlserver.database.windows.net:1433;database=synapsedw;encrypt=false;"+
  "encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net")
sqldwJDBC = ("jdbc:sqlserver://pysparksqlserver.database.windows.net:1433;database=synapsedw;encrypt=false;"+
  "encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;user=pysparkadmin;password=password")

tempDir="wasbs://sales@adlsgen2pysparks.blob.core.windows.net/tmp"

# COMMAND ----------

# MAGIC %run "/Shared/Pyspark_Project_Dynamic/utils/libraries"

# COMMAND ----------

# MAGIC %run "/Shared/Pyspark_Project_Dynamic/utils/functions"

# COMMAND ----------

func_create_widgets(("curation_zone_database_name","curation_zone_table_name","curation_zone_table_pk_column","dw_zone_database_name","dw_zone_table_name","dw_zone_table_pk_column","job_id","job_name"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Accessing data from SQL Data Warehouse

# COMMAND ----------

curation_zone_database_name="curation_sales"
curation_zone_table_name="curation_channels"
df_stg = spark.sql("select * from "+curation_zone_database_name+"."+curation_zone_table_name)

# COMMAND ----------

# MAGIC %md
# MAGIC You can load data into your Azure Databricks environment by issuing a SQL query against the SQL Data Warehouse, as follows:

# COMMAND ----------

df = (spark.read.format("com.databricks.spark.sqldw")
                .option("url", jdbcString)
                .option("tempDir", "wasbs://sales@adlsgen2pysparks.blob.core.windows.net/tmp")
                .option("forward_spark_azure_storage_credentials", "true")
                .option("user",username)
                .option("password",password)
                .option("query", "select * from dbo.stg_channels")
                .load())
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Writing new data to SQL Data Warehouse

# COMMAND ----------

dbtable="stg_channels"
df_stg.write.format("com.databricks.spark.sqldw")\
                .option("url", jdbcString)\
                .option("tempDir", "wasbs://sales@adlsgen2pysparks.blob.core.windows.net/tmp")\
                .option("forward_spark_azure_storage_credentials", "true")\
                .option("user","pysparkadmin")\
                .option("password",password)\
                .option("dbtable", dbtable)\
                .mode("overwrite")\
                .save()

# COMMAND ----------

df=df_stg
dwhStagingTable="stg_channels"
dwhTargetTable="target_channels"
lookupColumns = "CHANNEL_ID"
updatedDate=''
dwhStagingDistributionColumn="CHANNEL_ID"
tempDir="wasbs://sales@adlsgen2pysparks.blob.core.windows.net/tmp"
func_synapse_update_dwh(df,dwhStagingTable,dwhTargetTable,lookupColumns,updatedDate,dwhStagingDistributionColumn,sqldwJDBC,tempDir)

# COMMAND ----------

df = (spark.read.format("com.databricks.spark.sqldw")
                .option("url", jdbcString)
                .option("tempDir", "wasbs://sales@adlsgen2pysparks.blob.core.windows.net/tmp")
                .option("forward_spark_azure_storage_credentials", "true")
                .option("user",username)
                .option("password",password)
                .option("query", "select * from target_channels")
                .load())
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create two tables in synapse dw and delta to stage and stage to final table for incremental dataload

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE [dbo].[stg_channels]
# MAGIC (
# MAGIC 	[CHANNEL_ID] [int] NULL,
# MAGIC 	[CHANNEL_DESC] [nvarchar](256) NULL,
# MAGIC 	[CHANNEL_CLASS] [nvarchar](256) NULL,
# MAGIC 	[CHANNEL_CLASS_ID] [int] NULL,
# MAGIC 	[CHANNEL_TOTAL] [nvarchar](256) NULL,
# MAGIC 	[CHANNEL_TOTAL_ID] [int] NULL,
# MAGIC 	[CREATED_DATE] [datetime2](7) NULL,
# MAGIC 	[CREATED_BY] [nvarchar](256) NULL,
# MAGIC 	[UPDATED_DATE] [datetime2](7) NULL,
# MAGIC 	[UPDATED_BY] [nvarchar](256) NULL
# MAGIC )
# MAGIC WITH
# MAGIC (
# MAGIC 	DISTRIBUTION = ROUND_ROBIN,
# MAGIC 	CLUSTERED COLUMNSTORE INDEX
# MAGIC )
# MAGIC GO

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE [dbo].[target_channels]
# MAGIC (
# MAGIC 	[CHANNEL_ID] [int] NULL,
# MAGIC 	[CHANNEL_DESC] [nvarchar](256) NULL,
# MAGIC 	[CHANNEL_CLASS] [nvarchar](256) NULL,
# MAGIC 	[CHANNEL_CLASS_ID] [int] NULL,
# MAGIC 	[CHANNEL_TOTAL] [nvarchar](256) NULL,
# MAGIC 	[CHANNEL_TOTAL_ID] [int] NULL,
# MAGIC 	[CREATED_DATE] [datetime2](7) NULL,
# MAGIC 	[CREATED_BY] [nvarchar](256) NULL,
# MAGIC 	[UPDATED_DATE] [datetime2](7) NULL,
# MAGIC 	[UPDATED_BY] [nvarchar](256) NULL
# MAGIC )
# MAGIC WITH
# MAGIC (
# MAGIC 	DISTRIBUTION = ROUND_ROBIN,
# MAGIC 	CLUSTERED COLUMNSTORE INDEX
# MAGIC )
# MAGIC GO