# Databricks notebook source
# MAGIC %md
# MAGIC ###### Getting data from common job config table `jobs.job_list_dynamic`

# COMMAND ----------

df_jobs_list = spark.sql("select * from jobs.JOB_LIST_DYNAMIC where job_status=1   order by job_id asc")

# COMMAND ----------

display(df_jobs_list)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Processing dynamically all notebooks using `job config` table with `dbutils.notebook.run()` for __`Dimension tables`__

# COMMAND ----------

output=""
for load in df_jobs_list.rdd.collect():
  output =dbutils.notebook.run("NB_sales_landing_staging",timeout_seconds=6000,arguments={"landing_zone_file_path":load["landing_zone_file_path"],"landing_zone_folder_name":load["landing_zone_folder_name"],"landing_zone_file_name":load["landing_zone_file_name"],"landing_zone_file_type":load["landing_zone_file_type"],"staging_zone_database_name":load["staging_zone_database_name"],"staging_zone_table_name":load["staging_zone_table_name"],"staging_zone_table_pk_column":load["staging_zone_table_pk_column"],"pyspark_schema":load["pyspark_schema"],"job_id":load["job_id"],"job_name":load["job_name"]})
  output=output+output
  print(output)

# COMMAND ----------

curated_output=""
for load in df_jobs_list.rdd.collect():
  curated_output = dbutils.notebook.run("NB_sales_staging_curated",timeout_seconds=6000,arguments={"staging_zone_database_name":load["staging_zone_database_name"],"staging_zone_table_name":load["staging_zone_table_name"],"staging_zone_table_pk_column":load["staging_zone_table_pk_column"],"curation_zone_database_name":load["curation_zone_database_name"],"curation_zone_table_name":load["curation_zone_table_name"],"curation_zone_table_pk_column":load["curation_zone_table_pk_column"],"dw_zone_database_name":load["dw_zone_database_name"],"dw_zone_table_name":load["dw_zone_table_name"],"dw_zone_table_pk_column":load["dw_zone_table_pk_column"],"pyspark_schema":load["pyspark_schema"],"job_id":load["job_id"],"job_name":load["job_name"]})
  curated_output=curated_output+curated_output
  print(curated_output)

# COMMAND ----------

df_jobs_list = spark.sql("select * from jobs.JOB_LIST_DYNAMIC where job_status=1 and table_type='dim'  order by job_id asc")
display(df_jobs_list)

# COMMAND ----------

dwh_output=""
for load in df_jobs_list.rdd.collect():
  output = dbutils.notebook.run("./NB_sales_curation_dwh",timeout_seconds=6000,arguments={"curation_zone_database_name":load["curation_zone_database_name"],"curation_zone_table_name":load["curation_zone_table_name"],"curation_zone_table_pk_column":load["curation_zone_table_pk_column"],"dw_zone_database_name":load["dw_zone_database_name"],"dw_zone_table_name":load["dw_zone_table_name"],"dw_zone_table_pk_column":load["dw_zone_table_pk_column"],"pyspark_schema":load["pyspark_schema"],"job_id":load["job_id"],"job_name":load["job_name"]})
  dwh_output=dwh_output+output
  print(dwh_output)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Getting data from common job config table `jobs.job_list_dynamic` For __`Fact tables`__

# COMMAND ----------

df_jobs_fact_list = spark.sql("select * from jobs.JOB_LIST_DYNAMIC where job_status=1 and table_type='fact' order by job_id asc")

# COMMAND ----------

for load in df_jobs_fact_list.rdd.collect():
  if load["job_name"]=="costs_transaction" :
    dbutils.notebook.run("NB_costs_fact_load",timeout_seconds=6000,arguments={"landing_zone_file_path":load["landing_zone_file_path"],"landing_zone_folder_name":load["landing_zone_folder_name"],"landing_zone_file_name":load["landing_zone_file_name"],"landing_zone_file_type":load["landing_zone_file_type"],"staging_zone_database_name":load["staging_zone_database_name"],"staging_zone_table_name":load["staging_zone_table_name"],"staging_zone_table_pk_column":load["staging_zone_table_pk_column"],"curation_zone_database_name":load["curation_zone_database_name"],"curation_zone_table_name":load["curation_zone_table_name"],"curation_zone_table_pk_column":load["curation_zone_table_pk_column"],"dw_zone_database_name":load["dw_zone_database_name"],"dw_zone_table_name":load["dw_zone_table_name"],"dw_zone_table_pk_column":load["dw_zone_table_pk_column"],"pyspark_schema":load["pyspark_schema"]})
  elif load["job_name"]=="sales_transaction" :
    dbutils.notebook.run("NB_sales_fact_load",timeout_seconds=6000,arguments={"landing_zone_file_path":load["landing_zone_file_path"],"landing_zone_folder_name":load["landing_zone_folder_name"],"landing_zone_file_name":load["landing_zone_file_name"],"landing_zone_file_type":load["landing_zone_file_type"],"staging_zone_database_name":load["staging_zone_database_name"],"staging_zone_table_name":load["staging_zone_table_name"],"staging_zone_table_pk_column":load["staging_zone_table_pk_column"],"curation_zone_database_name":load["curation_zone_database_name"],"curation_zone_table_name":load["curation_zone_table_name"],"curation_zone_table_pk_column":load["curation_zone_table_pk_column"],"dw_zone_database_name":load["dw_zone_database_name"],"dw_zone_table_name":load["dw_zone_table_name"],"dw_zone_table_pk_column":load["dw_zone_table_pk_column"],"pyspark_schema":load["pyspark_schema"]})

# COMMAND ----------

